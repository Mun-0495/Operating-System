#include "types.h"
#include "stat.h"
#include "user.h"
#include "proc.h"

int main(int argc, char* argv[]) {
	int pid = fork();

	if(pid != 0) {
		
	}
	exit();
}
